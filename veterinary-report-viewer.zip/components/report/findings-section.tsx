'use client'

import { useState } from 'react'
import { Plus, Filter } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { FindingCard } from './finding-card'
import type { AIFinding, StudyImage } from '@/lib/mock-report-data'

interface FindingsSectionProps {
  findings: AIFinding[]
  images: StudyImage[]
  onUpdateFinding: (id: string, updates: Partial<AIFinding>) => void
  onAddFinding: () => void
}

type FilterType = 'all' | 'pending' | 'accepted' | 'edited'

export function FindingsSection({
  findings,
  images,
  onUpdateFinding,
  onAddFinding
}: FindingsSectionProps) {
  const [showChanges, setShowChanges] = useState(false)
  const [filter, setFilter] = useState<FilterType>('all')

  const filteredFindings = findings.filter(finding => {
    if (filter === 'all') return true
    return finding.status === filter
  })

  const getImageForFinding = (finding: AIFinding): StudyImage | undefined => {
    return images.find(img => img.id === finding.linkedImageId)
  }

  const pendingCount = findings.filter(f => f.status === 'pending').length
  const acceptedCount = findings.filter(f => f.status === 'accepted').length
  const editedCount = findings.filter(f => f.status === 'edited').length

  return (
    <section className="space-y-4">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Hallazgos</h2>
          <p className="text-sm text-muted-foreground">
            {pendingCount} pendientes, {acceptedCount} validados, {editedCount} editados
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <Switch
              id="show-changes"
              checked={showChanges}
              onCheckedChange={setShowChanges}
            />
            <Label htmlFor="show-changes" className="text-sm cursor-pointer">
              Mostrar Cambios
            </Label>
          </div>

          <Select value={filter} onValueChange={(v) => setFilter(v as FilterType)}>
            <SelectTrigger className="w-[140px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Filtrar" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos ({findings.length})</SelectItem>
              <SelectItem value="pending">Pendientes ({pendingCount})</SelectItem>
              <SelectItem value="accepted">Validados ({acceptedCount})</SelectItem>
              <SelectItem value="edited">Editados ({editedCount})</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-3">
        {filteredFindings.map((finding) => (
          <FindingCard
            key={finding.id}
            finding={finding}
            image={getImageForFinding(finding)}
            showChanges={showChanges}
            onUpdate={onUpdateFinding}
          />
        ))}
      </div>

      <Button
        variant="outline"
        onClick={onAddFinding}
        className="w-full gap-2 border-dashed bg-transparent"
      >
        <Plus className="h-4 w-4" />
        Agregar hallazgo manualmente
      </Button>
    </section>
  )
}
