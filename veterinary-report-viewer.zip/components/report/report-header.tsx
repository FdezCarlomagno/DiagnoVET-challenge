'use client'

import { ArrowLeft, Download, Pencil, Settings, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useState } from 'react'

interface ReportHeaderProps {
  patientName: string
  species: string
  breed: string
  date: string
  onBack?: () => void
  onPrintPdf?: () => Promise<void>
  onEditCase?: () => void
  onSettings?: () => void
}

export function ReportHeader({
  patientName,
  species,
  breed,
  date,
  onBack,
  onPrintPdf,
  onEditCase,
  onSettings
}: ReportHeaderProps) {
  const [isPrinting, setIsPrinting] = useState(false)

  const handlePrintPdf = async () => {
    if (!onPrintPdf) return
    setIsPrinting(true)
    try {
      await onPrintPdf()
    } finally {
      setIsPrinting(false)
    }
  }

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="gap-2 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            <span className="hidden sm:inline">Volver a listado de reportes</span>
            <span className="sm:hidden">Volver</span>
          </Button>
        </div>

        <div className="flex flex-col items-center">
          <h1 className="text-lg font-semibold text-foreground">{patientName}</h1>
          <p className="text-sm text-muted-foreground">
            {species} - {breed} | {date}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={handlePrintPdf}
            disabled={isPrinting}
            className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
          >
            {isPrinting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                <span className="hidden sm:inline">Generando PDF...</span>
              </>
            ) : (
              <>
                <Download className="h-4 w-4" />
                <span className="hidden sm:inline">Imprimir PDF</span>
              </>
            )}
          </Button>
          <Button variant="outline" onClick={onEditCase} className="gap-2 bg-transparent">
            <Pencil className="h-4 w-4" />
            <span className="hidden sm:inline">Editar Caso</span>
          </Button>
          <Button variant="ghost" size="icon" onClick={onSettings}>
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  )
}
