'use client'

import { useState } from 'react'
import type { AIFinding, StudyImage } from '@/lib/mock-report-data'
import { getStatusColor, getConfidenceColor } from '@/lib/mock-report-data'
import { ConfidenceBadge } from './confidence-badge'
import { FindingActions } from './finding-actions'
import { InlineEditor } from './inline-editor'
import { ImageThumbnail } from './image-thumbnail'
import { DiffViewer } from './diff-viewer'
import { HighlightedText } from './highlighted-text'

interface FindingCardProps {
  finding: AIFinding
  image?: StudyImage
  showChanges: boolean
  onUpdate: (id: string, updates: Partial<AIFinding>) => void
}

export function FindingCard({ finding, image, showChanges, onUpdate }: FindingCardProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [isRegenerating, setIsRegenerating] = useState(false)
  const statusColor = getStatusColor(finding.status)
  const confidenceColors = getConfidenceColor(finding.confidence)

  const handleAccept = () => {
    onUpdate(finding.id, { status: 'accepted' })
  }

  const handleEdit = () => {
    setIsEditing(true)
  }

  const handleSave = (newText: string) => {
    onUpdate(finding.id, {
      currentText: newText,
      isEdited: newText !== finding.originalText,
      status: newText !== finding.originalText ? 'edited' : finding.status,
      editedBy: newText !== finding.originalText ? 'Dr. Usuario' : finding.editedBy,
      editedAt: newText !== finding.originalText 
        ? new Date().toLocaleString('es-ES', { 
            day: '2-digit', 
            month: '2-digit', 
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          })
        : finding.editedAt
    })
    setIsEditing(false)
  }

  const handleCancel = () => {
    setIsEditing(false)
  }

  const handleRegenerate = async () => {
    setIsRegenerating(true)
    // Simulate AI regeneration
    await new Promise(resolve => setTimeout(resolve, 2500))
    onUpdate(finding.id, {
      currentText: finding.originalText + ' [Regenerado por AI]',
      isEdited: false,
      status: 'pending'
    })
    setIsRegenerating(false)
  }

  // Determine background based on status when showChanges is enabled
  const getBgColor = () => {
    if (!showChanges) return 'bg-card'
    if (finding.status === 'edited') return 'bg-emerald-50/50'
    if (finding.status === 'accepted') return 'bg-card'
    return 'bg-blue-50/30'
  }

  if (isEditing) {
    return (
      <div className={`rounded-lg border-l-4 ${statusColor}`}>
        <InlineEditor
          initialContent={finding.currentText}
          onSave={handleSave}
          onCancel={handleCancel}
          title={finding.organ}
        />
      </div>
    )
  }

  return (
    <div
      className={`group rounded-lg border border-border ${getBgColor()} transition-all hover:shadow-md border-l-4 ${statusColor}`}
    >
      <div className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            {image && (
              <ImageThumbnail image={image} organName={finding.organ} />
            )}
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h4 className="font-medium text-foreground">{finding.organ}</h4>
                <ConfidenceBadge
                  confidence={finding.confidence}
                  status={finding.status}
                  editedBy={finding.editedBy}
                  editedAt={finding.editedAt}
                />
              </div>
            </div>
          </div>
          <div className="opacity-0 transition-opacity group-hover:opacity-100">
            <FindingActions
              status={finding.status}
              isRegenerating={isRegenerating}
              onAccept={handleAccept}
              onEdit={handleEdit}
              onRegenerate={handleRegenerate}
            />
          </div>
        </div>

        <div className="mt-3">
          <p className="text-sm leading-relaxed text-foreground/90">
            <HighlightedText
              text={finding.currentText}
              abnormalValues={finding.abnormalValues}
              showHighlights={showChanges}
            />
          </p>
        </div>

        {finding.isEdited && showChanges && (
          <DiffViewer
            originalText={finding.originalText}
            currentText={finding.currentText}
            editedBy={finding.editedBy}
          />
        )}
      </div>
    </div>
  )
}
