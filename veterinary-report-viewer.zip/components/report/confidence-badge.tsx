'use client'

import { Bot, CheckCircle2, AlertTriangle, Pencil } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { getConfidenceColor } from '@/lib/mock-report-data'
import type { AIFinding } from '@/lib/mock-report-data'

interface ConfidenceBadgeProps {
  confidence: number
  status: AIFinding['status']
  editedBy?: string
  editedAt?: string
}

export function ConfidenceBadge({ confidence, status, editedBy, editedAt }: ConfidenceBadgeProps) {
  const colors = getConfidenceColor(confidence)
  const percentage = Math.round(confidence * 100)

  if (status === 'accepted') {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Badge
              variant="outline"
              className="gap-1.5 border-emerald-300 bg-emerald-100 text-emerald-800"
            >
              <CheckCircle2 className="h-3 w-3" />
              Validado
            </Badge>
          </TooltipTrigger>
          <TooltipContent>
            <p>Hallazgo validado por el veterinario</p>
            <p className="text-xs text-muted-foreground">Confianza AI: {percentage}%</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  }

  if (status === 'edited') {
    return (
      <div className="flex items-center gap-2">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge
                variant="outline"
                className="gap-1.5 border-blue-300 bg-blue-100 text-blue-800"
              >
                <Pencil className="h-3 w-3" />
                Editado
              </Badge>
            </TooltipTrigger>
            <TooltipContent>
              <p>Editado por {editedBy}</p>
              <p className="text-xs text-muted-foreground">{editedAt}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <Badge variant="outline" className={`gap-1.5 ${colors.badge}`}>
          <Bot className="h-3 w-3" />
          AI {percentage}%
        </Badge>
      </div>
    )
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge variant="outline" className={`gap-1.5 ${colors.badge}`}>
            {confidence < 0.6 && <AlertTriangle className="h-3 w-3" />}
            <Bot className="h-3 w-3" />
            AI {percentage}%
            {confidence < 0.6 && <span className="hidden sm:inline">- Revisar</span>}
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          {confidence >= 0.9 && <p>Alta confianza - El modelo está seguro de este hallazgo</p>}
          {confidence >= 0.6 && confidence < 0.9 && (
            <p>Confianza media - Recomendamos revisar este hallazgo</p>
          )}
          {confidence < 0.6 && (
            <p className="text-amber-600">Baja confianza - Este hallazgo requiere revisión manual</p>
          )}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
