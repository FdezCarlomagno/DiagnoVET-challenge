import type { PatientInfo } from '@/lib/mock-report-data'

interface PatientInfoCardProps {
  patient: PatientInfo
}

export function PatientInfoCard({ patient }: PatientInfoCardProps) {
  const infoItems = [
    { label: 'Nombre', value: patient.name },
    { label: 'Fecha', value: patient.date },
    { label: 'Especie', value: patient.species },
    { label: 'Tutor', value: patient.tutor },
    { label: 'Sexo', value: patient.sex },
    { label: 'Raza', value: patient.breed },
    { label: 'Veterinario', value: patient.veterinarian },
    { label: 'Edad', value: patient.age },
    { label: 'Tipo de Ecografía', value: patient.studyType, fullWidth: true },
  ]

  return (
    <section className="space-y-4">
      <h2 className="text-xl font-semibold text-foreground">Informe Ecográfico</h2>
      <div className="rounded-lg border border-border bg-card p-6">
        <div className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
          {infoItems.map((item) => (
            <div
              key={item.label}
              className={`flex items-baseline gap-2 ${item.fullWidth ? 'sm:col-span-2' : ''}`}
            >
              <span className="text-sm font-medium text-muted-foreground">
                {item.label}:
              </span>
              <span className="text-sm text-foreground">{item.value}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
