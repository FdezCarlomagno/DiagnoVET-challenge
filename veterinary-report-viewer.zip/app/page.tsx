'use client'

import { useState, useCallback } from 'react'
import { AppHeader } from '@/components/report/app-header'
import { ReportHeader } from '@/components/report/report-header'
import { PatientInfoCard } from '@/components/report/patient-info-card'
import { DiagnosisSection } from '@/components/report/diagnosis-section'
import { FindingsSection } from '@/components/report/findings-section'
import { ImageGallery } from '@/components/report/image-gallery'
import { Separator } from '@/components/ui/separator'
import { mockReport, type AIFinding, type Diagnosis, type Report } from '@/lib/mock-report-data'
import { Toaster } from '@/components/ui/sonner'
import { toast } from 'sonner'

export default function ReportViewerPage() {
  const [report, setReport] = useState<Report>(mockReport)

  const handleUpdateFinding = useCallback((id: string, updates: Partial<AIFinding>) => {
    setReport(prev => ({
      ...prev,
      findings: prev.findings.map(finding =>
        finding.id === id ? { ...finding, ...updates } : finding
      )
    }))

    if (updates.status === 'accepted') {
      toast.success('Hallazgo validado', {
        description: 'El hallazgo ha sido marcado como validado por el veterinario.'
      })
    } else if (updates.status === 'edited') {
      toast.success('Cambios guardados', {
        description: 'El hallazgo ha sido actualizado correctamente.'
      })
    }
  }, [])

  const handleUpdateDiagnosis = useCallback((updates: Partial<Diagnosis>) => {
    setReport(prev => ({
      ...prev,
      diagnosis: { ...prev.diagnosis, ...updates }
    }))

    if (updates.status === 'accepted') {
      toast.success('Diagnóstico validado', {
        description: 'El diagnóstico ha sido marcado como validado.'
      })
    } else if (updates.status === 'edited') {
      toast.success('Diagnóstico actualizado', {
        description: 'Los cambios han sido guardados.'
      })
    }
  }, [])

  const handleAddFinding = useCallback(() => {
    const newFinding: AIFinding = {
      id: `finding-${Date.now()}`,
      organ: 'Nuevo Hallazgo',
      confidence: 0,
      originalText: '',
      currentText: '',
      isEdited: true,
      editedBy: 'Dr. Usuario',
      editedAt: new Date().toLocaleString('es-ES'),
      status: 'edited',
      linkedImageId: report.images[0]?.id || ''
    }

    setReport(prev => ({
      ...prev,
      findings: [...prev.findings, newFinding]
    }))

    toast.info('Nuevo hallazgo agregado', {
      description: 'Haz clic en el hallazgo para editarlo.'
    })
  }, [report.images])

  const handlePrintPdf = async () => {
    // Simulate PDF generation
    await new Promise(resolve => setTimeout(resolve, 2000))
    toast.success('PDF generado', {
      description: 'El reporte PDF está listo para descargar.'
    })
  }

  const handleBack = () => {
    toast.info('Navegación', {
      description: 'Volviendo al listado de reportes...'
    })
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <AppHeader />
      <ReportHeader
        patientName={report.patientInfo.name}
        species={report.patientInfo.species}
        breed={report.patientInfo.breed}
        date={report.patientInfo.date}
        onBack={handleBack}
        onPrintPdf={handlePrintPdf}
      />

      <main className="mx-auto max-w-4xl px-4 py-8">
        <div className="space-y-8">
          <PatientInfoCard patient={report.patientInfo} />

          <Separator />

          <DiagnosisSection
            diagnosis={report.diagnosis}
            onUpdate={handleUpdateDiagnosis}
          />

          <Separator />

          <FindingsSection
            findings={report.findings}
            images={report.images}
            onUpdateFinding={handleUpdateFinding}
            onAddFinding={handleAddFinding}
          />

          <Separator />

          <ImageGallery images={report.images} />
        </div>
      </main>

      <Toaster position="bottom-right" />
    </div>
  )
}
